/**
 */
package boundingbox.tests;

import boundingbox.MoveX;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Move X</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class MoveXTest extends MoveTest {

	/**
	 * Constructs a new Move X test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MoveXTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Move X test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected MoveX getFixture() {
		return (MoveX)fixture;
	}

} //MoveXTest
