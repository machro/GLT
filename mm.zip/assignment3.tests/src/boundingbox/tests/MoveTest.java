/**
 */
package boundingbox.tests;

import boundingbox.Move;

import junit.framework.TestCase;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Move</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class MoveTest extends TestCase {

	/**
	 * The fixture for this Move test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Move fixture = null;

	/**
	 * Constructs a new Move test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MoveTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Move test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Move fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Move test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Move getFixture() {
		return fixture;
	}

} //MoveTest
