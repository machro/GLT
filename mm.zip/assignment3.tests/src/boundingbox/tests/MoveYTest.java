/**
 */
package boundingbox.tests;

import boundingbox.MoveY;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Move Y</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class MoveYTest extends MoveTest {

	/**
	 * Constructs a new Move Y test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public MoveYTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Move Y test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected MoveY getFixture() {
		return (MoveY)fixture;
	}

} //MoveYTest
