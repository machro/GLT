package nl.tue.glt.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import nl.tue.glt.services.BoundingBoxGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalBoundingBoxParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_INT", "RULE_ID", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Box:'", "'left'", "'right'", "'up'", "'down'"
    };
    public static final int RULE_ID=5;
    public static final int RULE_WS=9;
    public static final int RULE_STRING=6;
    public static final int RULE_ANY_OTHER=10;
    public static final int RULE_SL_COMMENT=8;
    public static final int T__15=15;
    public static final int RULE_INT=4;
    public static final int T__11=11;
    public static final int RULE_ML_COMMENT=7;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;

    // delegates
    // delegators


        public InternalBoundingBoxParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalBoundingBoxParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalBoundingBoxParser.tokenNames; }
    public String getGrammarFileName() { return "InternalBoundingBox.g"; }



     	private BoundingBoxGrammarAccess grammarAccess;

        public InternalBoundingBoxParser(TokenStream input, BoundingBoxGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "World";
       	}

       	@Override
       	protected BoundingBoxGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleWorld"
    // InternalBoundingBox.g:64:1: entryRuleWorld returns [EObject current=null] : iv_ruleWorld= ruleWorld EOF ;
    public final EObject entryRuleWorld() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleWorld = null;


        try {
            // InternalBoundingBox.g:64:46: (iv_ruleWorld= ruleWorld EOF )
            // InternalBoundingBox.g:65:2: iv_ruleWorld= ruleWorld EOF
            {
             newCompositeNode(grammarAccess.getWorldRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleWorld=ruleWorld();

            state._fsp--;

             current =iv_ruleWorld; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleWorld"


    // $ANTLR start "ruleWorld"
    // InternalBoundingBox.g:71:1: ruleWorld returns [EObject current=null] : ( () otherlv_1= 'Box:' ( (lv_moveCommands_2_0= ruleMove ) )* ) ;
    public final EObject ruleWorld() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        EObject lv_moveCommands_2_0 = null;



        	enterRule();

        try {
            // InternalBoundingBox.g:77:2: ( ( () otherlv_1= 'Box:' ( (lv_moveCommands_2_0= ruleMove ) )* ) )
            // InternalBoundingBox.g:78:2: ( () otherlv_1= 'Box:' ( (lv_moveCommands_2_0= ruleMove ) )* )
            {
            // InternalBoundingBox.g:78:2: ( () otherlv_1= 'Box:' ( (lv_moveCommands_2_0= ruleMove ) )* )
            // InternalBoundingBox.g:79:3: () otherlv_1= 'Box:' ( (lv_moveCommands_2_0= ruleMove ) )*
            {
            // InternalBoundingBox.g:79:3: ()
            // InternalBoundingBox.g:80:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getWorldAccess().getWorldAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,11,FOLLOW_3); 

            			newLeafNode(otherlv_1, grammarAccess.getWorldAccess().getBoxKeyword_1());
            		
            // InternalBoundingBox.g:90:3: ( (lv_moveCommands_2_0= ruleMove ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=12 && LA1_0<=15)) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalBoundingBox.g:91:4: (lv_moveCommands_2_0= ruleMove )
            	    {
            	    // InternalBoundingBox.g:91:4: (lv_moveCommands_2_0= ruleMove )
            	    // InternalBoundingBox.g:92:5: lv_moveCommands_2_0= ruleMove
            	    {

            	    					newCompositeNode(grammarAccess.getWorldAccess().getMoveCommandsMoveParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_3);
            	    lv_moveCommands_2_0=ruleMove();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getWorldRule());
            	    					}
            	    					add(
            	    						current,
            	    						"moveCommands",
            	    						lv_moveCommands_2_0,
            	    						"nl.tue.glt.BoundingBox.Move");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleWorld"


    // $ANTLR start "entryRuleMove"
    // InternalBoundingBox.g:113:1: entryRuleMove returns [EObject current=null] : iv_ruleMove= ruleMove EOF ;
    public final EObject entryRuleMove() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMove = null;


        try {
            // InternalBoundingBox.g:113:45: (iv_ruleMove= ruleMove EOF )
            // InternalBoundingBox.g:114:2: iv_ruleMove= ruleMove EOF
            {
             newCompositeNode(grammarAccess.getMoveRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMove=ruleMove();

            state._fsp--;

             current =iv_ruleMove; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMove"


    // $ANTLR start "ruleMove"
    // InternalBoundingBox.g:120:1: ruleMove returns [EObject current=null] : (this_MoveLeft_0= ruleMoveLeft | this_MoveRight_1= ruleMoveRight | this_MoveUp_2= ruleMoveUp | this_MoveDown_3= ruleMoveDown ) ;
    public final EObject ruleMove() throws RecognitionException {
        EObject current = null;

        EObject this_MoveLeft_0 = null;

        EObject this_MoveRight_1 = null;

        EObject this_MoveUp_2 = null;

        EObject this_MoveDown_3 = null;



        	enterRule();

        try {
            // InternalBoundingBox.g:126:2: ( (this_MoveLeft_0= ruleMoveLeft | this_MoveRight_1= ruleMoveRight | this_MoveUp_2= ruleMoveUp | this_MoveDown_3= ruleMoveDown ) )
            // InternalBoundingBox.g:127:2: (this_MoveLeft_0= ruleMoveLeft | this_MoveRight_1= ruleMoveRight | this_MoveUp_2= ruleMoveUp | this_MoveDown_3= ruleMoveDown )
            {
            // InternalBoundingBox.g:127:2: (this_MoveLeft_0= ruleMoveLeft | this_MoveRight_1= ruleMoveRight | this_MoveUp_2= ruleMoveUp | this_MoveDown_3= ruleMoveDown )
            int alt2=4;
            switch ( input.LA(1) ) {
            case 12:
                {
                alt2=1;
                }
                break;
            case 13:
                {
                alt2=2;
                }
                break;
            case 14:
                {
                alt2=3;
                }
                break;
            case 15:
                {
                alt2=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }

            switch (alt2) {
                case 1 :
                    // InternalBoundingBox.g:128:3: this_MoveLeft_0= ruleMoveLeft
                    {

                    			newCompositeNode(grammarAccess.getMoveAccess().getMoveLeftParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_MoveLeft_0=ruleMoveLeft();

                    state._fsp--;


                    			current = this_MoveLeft_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalBoundingBox.g:137:3: this_MoveRight_1= ruleMoveRight
                    {

                    			newCompositeNode(grammarAccess.getMoveAccess().getMoveRightParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_MoveRight_1=ruleMoveRight();

                    state._fsp--;


                    			current = this_MoveRight_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalBoundingBox.g:146:3: this_MoveUp_2= ruleMoveUp
                    {

                    			newCompositeNode(grammarAccess.getMoveAccess().getMoveUpParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_MoveUp_2=ruleMoveUp();

                    state._fsp--;


                    			current = this_MoveUp_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalBoundingBox.g:155:3: this_MoveDown_3= ruleMoveDown
                    {

                    			newCompositeNode(grammarAccess.getMoveAccess().getMoveDownParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_MoveDown_3=ruleMoveDown();

                    state._fsp--;


                    			current = this_MoveDown_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMove"


    // $ANTLR start "entryRuleEInt"
    // InternalBoundingBox.g:167:1: entryRuleEInt returns [String current=null] : iv_ruleEInt= ruleEInt EOF ;
    public final String entryRuleEInt() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleEInt = null;


        try {
            // InternalBoundingBox.g:167:44: (iv_ruleEInt= ruleEInt EOF )
            // InternalBoundingBox.g:168:2: iv_ruleEInt= ruleEInt EOF
            {
             newCompositeNode(grammarAccess.getEIntRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleEInt=ruleEInt();

            state._fsp--;

             current =iv_ruleEInt.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleEInt"


    // $ANTLR start "ruleEInt"
    // InternalBoundingBox.g:174:1: ruleEInt returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : this_INT_0= RULE_INT ;
    public final AntlrDatatypeRuleToken ruleEInt() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_INT_0=null;


        	enterRule();

        try {
            // InternalBoundingBox.g:180:2: (this_INT_0= RULE_INT )
            // InternalBoundingBox.g:181:2: this_INT_0= RULE_INT
            {
            this_INT_0=(Token)match(input,RULE_INT,FOLLOW_2); 

            		current.merge(this_INT_0);
            	

            		newLeafNode(this_INT_0, grammarAccess.getEIntAccess().getINTTerminalRuleCall());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleEInt"


    // $ANTLR start "entryRuleMoveLeft"
    // InternalBoundingBox.g:191:1: entryRuleMoveLeft returns [EObject current=null] : iv_ruleMoveLeft= ruleMoveLeft EOF ;
    public final EObject entryRuleMoveLeft() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMoveLeft = null;


        try {
            // InternalBoundingBox.g:191:49: (iv_ruleMoveLeft= ruleMoveLeft EOF )
            // InternalBoundingBox.g:192:2: iv_ruleMoveLeft= ruleMoveLeft EOF
            {
             newCompositeNode(grammarAccess.getMoveLeftRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMoveLeft=ruleMoveLeft();

            state._fsp--;

             current =iv_ruleMoveLeft; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMoveLeft"


    // $ANTLR start "ruleMoveLeft"
    // InternalBoundingBox.g:198:1: ruleMoveLeft returns [EObject current=null] : ( () otherlv_1= 'left' ( (lv_distance_2_0= ruleEInt ) ) ) ;
    public final EObject ruleMoveLeft() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        AntlrDatatypeRuleToken lv_distance_2_0 = null;



        	enterRule();

        try {
            // InternalBoundingBox.g:204:2: ( ( () otherlv_1= 'left' ( (lv_distance_2_0= ruleEInt ) ) ) )
            // InternalBoundingBox.g:205:2: ( () otherlv_1= 'left' ( (lv_distance_2_0= ruleEInt ) ) )
            {
            // InternalBoundingBox.g:205:2: ( () otherlv_1= 'left' ( (lv_distance_2_0= ruleEInt ) ) )
            // InternalBoundingBox.g:206:3: () otherlv_1= 'left' ( (lv_distance_2_0= ruleEInt ) )
            {
            // InternalBoundingBox.g:206:3: ()
            // InternalBoundingBox.g:207:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getMoveLeftAccess().getMoveLeftAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,12,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getMoveLeftAccess().getLeftKeyword_1());
            		
            // InternalBoundingBox.g:217:3: ( (lv_distance_2_0= ruleEInt ) )
            // InternalBoundingBox.g:218:4: (lv_distance_2_0= ruleEInt )
            {
            // InternalBoundingBox.g:218:4: (lv_distance_2_0= ruleEInt )
            // InternalBoundingBox.g:219:5: lv_distance_2_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getMoveLeftAccess().getDistanceEIntParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_distance_2_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMoveLeftRule());
            					}
            					add(
            						current,
            						"distance",
            						lv_distance_2_0,
            						"nl.tue.glt.BoundingBox.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMoveLeft"


    // $ANTLR start "entryRuleMoveRight"
    // InternalBoundingBox.g:240:1: entryRuleMoveRight returns [EObject current=null] : iv_ruleMoveRight= ruleMoveRight EOF ;
    public final EObject entryRuleMoveRight() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMoveRight = null;


        try {
            // InternalBoundingBox.g:240:50: (iv_ruleMoveRight= ruleMoveRight EOF )
            // InternalBoundingBox.g:241:2: iv_ruleMoveRight= ruleMoveRight EOF
            {
             newCompositeNode(grammarAccess.getMoveRightRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMoveRight=ruleMoveRight();

            state._fsp--;

             current =iv_ruleMoveRight; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMoveRight"


    // $ANTLR start "ruleMoveRight"
    // InternalBoundingBox.g:247:1: ruleMoveRight returns [EObject current=null] : ( () otherlv_1= 'right' ( (lv_distance_2_0= ruleEInt ) ) ) ;
    public final EObject ruleMoveRight() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        AntlrDatatypeRuleToken lv_distance_2_0 = null;



        	enterRule();

        try {
            // InternalBoundingBox.g:253:2: ( ( () otherlv_1= 'right' ( (lv_distance_2_0= ruleEInt ) ) ) )
            // InternalBoundingBox.g:254:2: ( () otherlv_1= 'right' ( (lv_distance_2_0= ruleEInt ) ) )
            {
            // InternalBoundingBox.g:254:2: ( () otherlv_1= 'right' ( (lv_distance_2_0= ruleEInt ) ) )
            // InternalBoundingBox.g:255:3: () otherlv_1= 'right' ( (lv_distance_2_0= ruleEInt ) )
            {
            // InternalBoundingBox.g:255:3: ()
            // InternalBoundingBox.g:256:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getMoveRightAccess().getMoveRightAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,13,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getMoveRightAccess().getRightKeyword_1());
            		
            // InternalBoundingBox.g:266:3: ( (lv_distance_2_0= ruleEInt ) )
            // InternalBoundingBox.g:267:4: (lv_distance_2_0= ruleEInt )
            {
            // InternalBoundingBox.g:267:4: (lv_distance_2_0= ruleEInt )
            // InternalBoundingBox.g:268:5: lv_distance_2_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getMoveRightAccess().getDistanceEIntParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_distance_2_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMoveRightRule());
            					}
            					add(
            						current,
            						"distance",
            						lv_distance_2_0,
            						"nl.tue.glt.BoundingBox.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMoveRight"


    // $ANTLR start "entryRuleMoveUp"
    // InternalBoundingBox.g:289:1: entryRuleMoveUp returns [EObject current=null] : iv_ruleMoveUp= ruleMoveUp EOF ;
    public final EObject entryRuleMoveUp() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMoveUp = null;


        try {
            // InternalBoundingBox.g:289:47: (iv_ruleMoveUp= ruleMoveUp EOF )
            // InternalBoundingBox.g:290:2: iv_ruleMoveUp= ruleMoveUp EOF
            {
             newCompositeNode(grammarAccess.getMoveUpRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMoveUp=ruleMoveUp();

            state._fsp--;

             current =iv_ruleMoveUp; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMoveUp"


    // $ANTLR start "ruleMoveUp"
    // InternalBoundingBox.g:296:1: ruleMoveUp returns [EObject current=null] : ( () otherlv_1= 'up' ( (lv_distance_2_0= ruleEInt ) ) ) ;
    public final EObject ruleMoveUp() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        AntlrDatatypeRuleToken lv_distance_2_0 = null;



        	enterRule();

        try {
            // InternalBoundingBox.g:302:2: ( ( () otherlv_1= 'up' ( (lv_distance_2_0= ruleEInt ) ) ) )
            // InternalBoundingBox.g:303:2: ( () otherlv_1= 'up' ( (lv_distance_2_0= ruleEInt ) ) )
            {
            // InternalBoundingBox.g:303:2: ( () otherlv_1= 'up' ( (lv_distance_2_0= ruleEInt ) ) )
            // InternalBoundingBox.g:304:3: () otherlv_1= 'up' ( (lv_distance_2_0= ruleEInt ) )
            {
            // InternalBoundingBox.g:304:3: ()
            // InternalBoundingBox.g:305:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getMoveUpAccess().getMoveUpAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,14,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getMoveUpAccess().getUpKeyword_1());
            		
            // InternalBoundingBox.g:315:3: ( (lv_distance_2_0= ruleEInt ) )
            // InternalBoundingBox.g:316:4: (lv_distance_2_0= ruleEInt )
            {
            // InternalBoundingBox.g:316:4: (lv_distance_2_0= ruleEInt )
            // InternalBoundingBox.g:317:5: lv_distance_2_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getMoveUpAccess().getDistanceEIntParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_distance_2_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMoveUpRule());
            					}
            					add(
            						current,
            						"distance",
            						lv_distance_2_0,
            						"nl.tue.glt.BoundingBox.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMoveUp"


    // $ANTLR start "entryRuleMoveDown"
    // InternalBoundingBox.g:338:1: entryRuleMoveDown returns [EObject current=null] : iv_ruleMoveDown= ruleMoveDown EOF ;
    public final EObject entryRuleMoveDown() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMoveDown = null;


        try {
            // InternalBoundingBox.g:338:49: (iv_ruleMoveDown= ruleMoveDown EOF )
            // InternalBoundingBox.g:339:2: iv_ruleMoveDown= ruleMoveDown EOF
            {
             newCompositeNode(grammarAccess.getMoveDownRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMoveDown=ruleMoveDown();

            state._fsp--;

             current =iv_ruleMoveDown; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMoveDown"


    // $ANTLR start "ruleMoveDown"
    // InternalBoundingBox.g:345:1: ruleMoveDown returns [EObject current=null] : ( () otherlv_1= 'down' ( (lv_distance_2_0= ruleEInt ) ) ) ;
    public final EObject ruleMoveDown() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        AntlrDatatypeRuleToken lv_distance_2_0 = null;



        	enterRule();

        try {
            // InternalBoundingBox.g:351:2: ( ( () otherlv_1= 'down' ( (lv_distance_2_0= ruleEInt ) ) ) )
            // InternalBoundingBox.g:352:2: ( () otherlv_1= 'down' ( (lv_distance_2_0= ruleEInt ) ) )
            {
            // InternalBoundingBox.g:352:2: ( () otherlv_1= 'down' ( (lv_distance_2_0= ruleEInt ) ) )
            // InternalBoundingBox.g:353:3: () otherlv_1= 'down' ( (lv_distance_2_0= ruleEInt ) )
            {
            // InternalBoundingBox.g:353:3: ()
            // InternalBoundingBox.g:354:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getMoveDownAccess().getMoveDownAction_0(),
            					current);
            			

            }

            otherlv_1=(Token)match(input,15,FOLLOW_4); 

            			newLeafNode(otherlv_1, grammarAccess.getMoveDownAccess().getDownKeyword_1());
            		
            // InternalBoundingBox.g:364:3: ( (lv_distance_2_0= ruleEInt ) )
            // InternalBoundingBox.g:365:4: (lv_distance_2_0= ruleEInt )
            {
            // InternalBoundingBox.g:365:4: (lv_distance_2_0= ruleEInt )
            // InternalBoundingBox.g:366:5: lv_distance_2_0= ruleEInt
            {

            					newCompositeNode(grammarAccess.getMoveDownAccess().getDistanceEIntParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_distance_2_0=ruleEInt();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMoveDownRule());
            					}
            					add(
            						current,
            						"distance",
            						lv_distance_2_0,
            						"nl.tue.glt.BoundingBox.EInt");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMoveDown"

    // Delegated rules


 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x000000000000F002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000000010L});

}