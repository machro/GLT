/**
 */
package boundingbox.impl;

import boundingbox.BoundingboxPackage;
import boundingbox.MoveLeft;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Move Left</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class MoveLeftImpl extends MoveXImpl implements MoveLeft {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MoveLeftImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return BoundingboxPackage.Literals.MOVE_LEFT;
	}

} //MoveLeftImpl
