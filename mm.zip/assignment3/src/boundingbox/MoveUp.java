/**
 */
package boundingbox;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Move Up</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boundingbox.BoundingboxPackage#getMoveUp()
 * @model
 * @generated
 */
public interface MoveUp extends MoveY {
} // MoveUp
