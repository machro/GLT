/**
 */
package boundingbox;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Move Down</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see boundingbox.BoundingboxPackage#getMoveDown()
 * @model
 * @generated
 */
public interface MoveDown extends MoveY {
} // MoveDown
