/**
 */
package platoon;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Turn</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see platoon.PlatoonPackage#getTurn()
 * @model abstract="true"
 * @generated
 */
public interface Turn extends Action {
} // Turn
