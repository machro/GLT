/**
 */
package platoon;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Left</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see platoon.PlatoonPackage#getLeft()
 * @model
 * @generated
 */
public interface Left extends Turn {
} // Left
