/**
 */
package platoon.impl;

import org.eclipse.emf.ecore.EClass;

import platoon.PlatoonPackage;
import platoon.Right;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Right</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class RightImpl extends TurnImpl implements Right {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected RightImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlatoonPackage.Literals.RIGHT;
	}

} //RightImpl
