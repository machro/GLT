/**
 */
package platoon.impl;

import org.eclipse.emf.ecore.EClass;

import platoon.Left;
import platoon.PlatoonPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Left</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class LeftImpl extends TurnImpl implements Left {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LeftImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return PlatoonPackage.Literals.LEFT;
	}

} //LeftImpl
